<?php if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('PBBB_MODO_TESTE', 'false');
define ('PBBB_CONVENIO_TESTE', '310143');
define ('PBBB_COBRANCA_TESTE', '2391953');
define ('PBBB_URL_RETORNO_TESTE', 'http://portalabrace.org/pagamentos/administrator/classes/payment/banco_do_brasil/retorno.php');
define ('PBBB_URL_INFORMA_TESTE', 'http://portalabrace.org/pagamentos/administrator/classes/payment/banco_do_brasil/informa.php');
define ('PBBB_DIAS_VENCIMENTO_TESTE', '5');
define ('PBBB_CONVENIO', '310143');
define ('PBBB_COBRANCA', '2391953');
define ('PBBB_URL_RETORNO', 'http://portalabrace.org/pagamentos/administrator/classes/payment/banco_do_brasil/retorno.php');
define ('PBBB_URL_INFORMA', 'http://portalabrace.org/pagamentos/administrator/classes/payment/banco_do_brasil/informa.php');
define ('PBBB_DIAS_VENCIMENTO', '5');
define ('PBBB_TRANSACAO_CONCLUIDA', 'C');
define ('PBBB_TRANSACAO_NAO_FINALIZADA', 'P');
define ('PBBB_TRANSACAO_CANCELADA', 'X');
